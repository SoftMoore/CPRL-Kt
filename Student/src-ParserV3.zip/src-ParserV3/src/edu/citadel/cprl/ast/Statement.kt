package edu.citadel.cprl.ast


/**
 * Base class for all CPRL statements.
 */
abstract class Statement : AST()
